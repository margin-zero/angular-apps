export class Corporation {
    id: number;
    name: string;
    city: number;
    country: number;
}